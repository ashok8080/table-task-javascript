let course=[
    {   
        sno:1,
        name:"Web Design",
        img:"3.jpg",
        content:"Web design refers to the design of websites that are<br> displayed on the internet. It usually refers to the user<br> experience aspects of website development rather<br> than software development.",
        price:15000,
        duration:"45Hrs"
    },
    {   
        sno:2,
        name:"Angular",
        img:"1.jpg",
        content:"Angular is a platform and framework for building single-page<br> client applications using HTML and TypeScript. Angular is<br> written in TypeScript. It implements core and optional<br> functionality as a set of TypeScript libraries that you<br>import into your applications.",
        price:20000,
        duration:"80Hrs"   
    },
    {   
        sno:3,
        name:"React",
        img:"2.png",
        content:"It's used for building interactive user interfaces<br> and web applications quickly and efficiently <br>with significantly less code than you would with<br> vanilla JavaScript. In React, you develop your<br> applications by creating reusable components that<br> you can think of as independent Lego blocks.",
        price:18000,
        duration:"60Hrs"   
    },
    {   
        sno:4,
        name:"PHP",
        img:"4.jpg",
        content:"PHP(short for Hypertext PreProcessor) is <br>the most widely used open source and general purpose<br> server side scripting language used mainly in web <br>development to create dynamic websites and<br> applications. It was developed in 1994 by Rasmus",
        price:15000,
        duration:"75Hrs"   
    },
    {  
         sno:5,
        name:"Java",
        img:"5.jpg",
        content:"Java is a platform-independent, object-oriented<br>programming language (OOP). It is not to beconfused with<br> JavaScript, a scriptinglanguageused to create dynamic<br> web pages. Due to its reliability and ease of use,<br> Java is one of themost popular programming<br> languages in the world.",
        price:25000,
        duration:"70Hrs"   
    },
    {  
        sno:6,
        name:"Python",
        img:"6.jpg",
        content:"Python is a computer programming language often <br>used to build websites and software, automate tasks,<br> and conduct data analysis. Python is a general-purpose <br>language, meaning it can be used to create a <br>variety of different programs and isn't<br> specialized for any specific problems.",
        price:22000,
        duration:"60Hrs"   
    }
    

]


let p=""
for(let a=0;a<course.length;a++){
    p+='<tbody><tr><td><h3>'+course[a].sno+'</h3></td><td><h3>'+course[a].name+'</h3></td><td><img src="images/'+course[a].img+'" alt="" width="100%" height="100px" ></td><td class="text-success w-50">'+course[a].content+'</td><td class="text-info" w-50><h3>'+course[a].price+'</h3></td><td class="text text-warning"><h3>'+course[a].duration+'</h3></td></tr></table>'
    }         

document.getElementById("browes").innerHTML=p;

